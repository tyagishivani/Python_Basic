
import math
D = 12
R = D/2
vol_sphere = 4/3 * math.pi * R * R
print(vol_sphere)