first_name = input('Enter the First name')
last_name = input('Enter the Last name')
print(first_name[::-1] + " "+last_name[::-1])

