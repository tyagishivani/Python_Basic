word = input('enter the word')
print(word[::-1])

